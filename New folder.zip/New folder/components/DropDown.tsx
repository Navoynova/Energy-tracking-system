"use client"
import React,{useState} from 'react'

const DropDown = () => {
    const [isOpen, setIsOpen] = useState(false)
    const [selectedDevice, setSelectedDevice] = useState("Device 1")
    const devices = ["Device 1", "Device 2", "Device 3"];
    const handleSelect = (device: string) => {
        setSelectedDevice(device);
        setIsOpen(false);
    };
  return (
    <div className="relative">
      <button
        className="bg-gray-200 px-4 py-2 rounded-lg text-sm font-medium"
        onClick={() => setIsOpen(!isOpen)}
      >
        {selectedDevice}
      </button>
      {isOpen && (
        <div className="absolute bg-white shadow-lg rounded-md mt-2 w-40 z-10">
          {devices.map((device) => (
            <button
              key={device}
              onClick={() => handleSelect(device)}
              className="block w-full text-left px-4 py-2 hover:bg-gray-100"
            >
              {device}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

export default DropDown