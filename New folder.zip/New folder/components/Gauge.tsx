import React from 'react';
import { Box, CircularProgress, Typography } from '@mui/material';

interface GaugeProps {
    value: number;
    maxValue: number;
    unit?: string;
}

const Gauge = ({ value, maxValue, unit }: GaugeProps) => {
    const percentage = Math.min((value / maxValue) * 100, 100);

    return (
        <Box position="relative" display="inline-flex">
            {/* Background Track */}
            <CircularProgress
                variant="determinate"
                value={100} // Always full for background track
                size={150}
                thickness={6}
                sx={{
                    color: "#e0e0e0", // Light gray track color
                    position: "absolute",
                }}
            />
            {/* Foreground Progress */}
            <CircularProgress
                variant="determinate"
                value={percentage}
                size={150}
                thickness={6}
                sx={{
                    color: "#f97316",
                }}
            />
            <Box
                top={0}
                left={0}
                bottom={0}
                right={0}
                position="absolute"
                display="flex"
                alignItems="center"
                justifyContent="center"
            >
                <Typography variant="h5" component="div" color="textPrimary">
                    {value}
                    {unit && <Typography variant="caption">{unit}</Typography>}
                </Typography>
            </Box>
        </Box>
    );
};

export default Gauge;
