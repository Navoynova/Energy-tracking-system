import React from 'react'
import Gauge from './Gauge';

interface MetricCardProps{
    title:string;
    value:number;
    unit:string;
    maxValue:number;
}

const MetricCard = ({title, value, unit, maxValue}:MetricCardProps) => {
  return (
    <div className='bg-gray-50 p-6 rounded-lg shadow'>
        <div className='flex items-center justify-between'>
            <h2 className='text-gray-600 font-medium'>{title}</h2>
            <Gauge value={value} maxValue={maxValue} unit={unit}/>
            <p className='mt-2 text-xl font-bold text-gray-700'>
                {value}
                <span className='text-sm font-medium text-gray-500'>{unit}</span>
            </p>
        </div>
    </div>
  )
}

export default MetricCard