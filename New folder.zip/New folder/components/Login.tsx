"use client"
import React,{useState} from 'react'
import { signInWithEmailAndPassword } from 'firebase/auth'
import {auth} from "../firebase";
import { useRouter } from 'next/navigation';
import Swal from 'sweetalert2';
import { FaUser} from "react-icons/fa";
const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const router = useRouter();

    const handleLogin = async(e:React.FormEvent) =>{
        e.preventDefault();
        setError("");
        try {
            await signInWithEmailAndPassword(auth,email,password);
            router.push("/home")
        } catch (error:any) {
            setError(error.message);
        }
    }

    const handleSignUp = () => {
        router.push("/signup");
      };
  return (
    <div className='flex justify-center items-center min-h-screen bg-gray-100'>
        <div className='bg-white p-8 rounded-2xl shadow-lg w-96'>
            <div className='flex flex-col items-center mb-6'>
                <div className='w-16 h-16 rounded-full bg-gray-300 flex items-center justify-center'>
                    <span className='text-gray-500 text-2xl'>
                        <FaUser/>
                    </span>
                </div>
                <h1 className='text-xl font-semibold mt-4'>Login</h1>
            </div>
            <form onSubmit={handleLogin} className='space-y-4'>
                {error && <p>{error}</p>}
                <input 
                    type="email"
                    placeholder='Enter your email'
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className='w-full p-3 rounded-md border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500' 
                    required
                />
                <input 
                    type="password"
                    placeholder='Password'
                    value={password}
                    onChange={(e) =>setPassword(e.target.value)} 
                    className='w-full p-3 rounded-md border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500' 
                    required
                />
                <button
                    type='submit'
                    className='w-full bg-teal-500 text-white py-3 rounded-md hover:bg-teal-600 cursor-pointer transition-all duration-300'
                >
                    Login
                </button>
            </form>
            <p className="mt-4 text-center text-gray-600 text-sm">
            Already Have an Account?{" "}
            <button onClick={handleSignUp} className="text-black font-bold">
                Signup
            </button>
            </p>
        </div>
    </div>
  )
}

export default Login