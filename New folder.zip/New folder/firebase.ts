
import { initializeApp } from "firebase/app";
import {getAuth} from "firebase/auth";
import { getDatabase } from "firebase/database";
const firebaseConfig = {
  apiKey: "AIzaSyDB-9laq51AbOhlvan6RK4pKyEjOE8_FTg",
  authDomain: "nibm-85b24.firebaseapp.com",
  projectId: "nibm-85b24",
  storageBucket: "nibm-85b24.firebasestorage.app",
  messagingSenderId: "721902416195",
  appId: "1:721902416195:web:48c052c3afb0e756c0bff6"
};
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const database = getDatabase(app);