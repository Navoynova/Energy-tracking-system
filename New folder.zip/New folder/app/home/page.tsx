"use client";

import React, { useEffect, useState } from "react";
import { database } from "@/firebase";
import { ref, onValue } from "firebase/database";
import { auth } from "@/firebase";
import { onAuthStateChanged, signOut } from "firebase/auth";
import MetricCard from "@/components/MetricCard";
import DropDown from "@/components/DropDown";
import { FaUser, FaBuilding, FaSignOutAlt } from "react-icons/fa";
import Swal from "sweetalert2";
import { useRouter } from "next/navigation";

const Page = () => {
  const [vrms, setVrms] = useState(0);
  const [irms, setIrms] = useState(0);
  const [power, setPower] = useState(0);
  const [kWh, setKWh] = useState(0);
  const [username, setUsername] = useState("User");
  const router = useRouter();

  useEffect(() => {
    const vrmsRef = ref(database, "energy/vrms");
    const irmsRef = ref(database, "energy/irms");
    const powerRef = ref(database, "energy/power");
    const kWhRef = ref(database, "energy/kWh");

    onValue(vrmsRef, (snapshot) => setVrms(snapshot.val() || 0));
    onValue(irmsRef, (snapshot) => setIrms(snapshot.val() || 0));
    onValue(powerRef, (snapshot) => setPower(snapshot.val() || 0));
    onValue(kWhRef, (snapshot) => setKWh(snapshot.val() || 0));
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        const userRef = ref(database, `users/${user.uid}`);
        onValue(userRef, (snapshot) => {
          const data = snapshot.val();
          if (data && data.username) {
            setUsername(data.username);
          }
        });
      }
    });

    return () => unsubscribe();
  }, []);

  const handleLogout = () => {
    Swal.fire({
      title: "Are you sure?",
      text: "You will be logged out and redirected to the login page.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, log out",
    }).then((result) => {
      if (result.isConfirmed) {
        signOut(auth)
          .then(() => {
            Swal.fire("Logged Out", "You have been logged out successfully.", "success");
            router.push("/login");
          })
          .catch(() => {
            Swal.fire("Error", "Failed to log out. Please try again.", "error");
          });
      }
    });
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4 sm:p-6">
      <div className="bg-white rounded-lg shadow-lg p-4 sm:p-6">
        {/* Header */}
        <div className="text-center mb-4 sm:mb-6">
          <h1 className="text-2xl sm:text-4xl font-bold text-gray-800">Smart Energy Meter</h1>
          <p className="text-xs sm:text-sm text-gray-600 flex flex-col sm:flex-row justify-center items-center space-y-2 sm:space-y-0 sm:space-x-4 mt-2">
            <span className="flex items-center space-x-1">
              <FaUser className="text-gray-500" />
              <span>{username}</span>
            </span>
            <span className="flex items-center space-x-1">
              <FaBuilding className="text-gray-500" />
              <span>My Organization - 8920BK</span>
            </span>
          </p>
        </div>

        {/* Status Section */}
        <div className="flex flex-col sm:flex-row justify-between items-center mb-4 sm:mb-6 space-y-2 sm:space-y-0">
          <DropDown />
          <button className="bg-gray-200 px-3 py-1 rounded-lg text-sm">LIVE</button>
          <div className="flex items-center space-x-2 sm:space-x-4">
            <span className="text-green-500 font-medium text-sm">Online</span>
            <button
              onClick={handleLogout}
              className="flex items-center space-x-1 bg-red-500 text-white px-3 py-1 rounded-lg hover:bg-red-600"
            >
              <FaSignOutAlt />
              <span>Log Out</span>
            </button>
          </div>
        </div>

        {/* Metrics Section */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          <MetricCard title="Vrms" value={vrms} unit="V" maxValue={500} />
          <MetricCard title="Irms" value={irms} unit="A" maxValue={30} />
          <MetricCard title="Power" value={power} unit="W" maxValue={100} />
          <MetricCard title="kWh" value={kWh} unit="kWh" maxValue={10} />
        </div>
      </div>
    </div>
  );
};

export default Page;
